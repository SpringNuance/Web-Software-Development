You can test the codes right away with typing this into terminal
deno test --allow-run --allow-net --allow-read --unstable --coverage=cov

Or you can paste the test code directly from tests/services/test into run-locally.js and type in the terminal
deno test --allow-run --allow-net --allow-read --unstable run-locally.js