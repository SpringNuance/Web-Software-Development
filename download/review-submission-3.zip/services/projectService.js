import { executeQuery } from "../database/database.js";
import * as issueService from "./issueService.js";

const create = async (name) => {
  await executeQuery("INSERT INTO projects (name) VALUES ($1);", name);
};

const deleteById = async (id) => {
  await issueService.deleteByProject(id);
  await executeQuery("DELETE FROM projects WHERE id = $1;",id);
};

const findAll = async () => {
  let result = await executeQuery("SELECT * FROM projects;");
  return result.rows;
};

const getById = async (id) => {
  let result = await executeQuery("SELECT * FROM projects WHERE id = $1;",id);
  return result.rows;
};

export { create, deleteById, findAll, getById };