<h1 align="center">
  <br>
  PMS
  <br>
</h1>

<h4 align="center">A simple project management system built with <a href="http://deno.land" target="_blank">Deno</a> for the <a href="https://wsd.cs.aalto.fi">WSD</a> course.</h4>

<p align="center">
  <a href="#structure">Program Structure</a> •
  <a href="#functions">Function Overview</a> •
  <a href="#how-to-use">How To Use</a>
</p>

## Program Structure

Main Program:

```
app.js - Controlls the web app routing.
```


Abstracted Functionality:

```
database.js - Used to communicate with the database server.
```


```
requestUtils.js - Used for easy implementation of POST-Redirect-GET method and other routing.
```


Controllers:

```
projectController.js - High level application functionality regarding projects.
```


```
issueController.js - High level application functionality regarding issues.
```


Services:

```
projectService.js - Low level application functionality regarding projects.
```


```
issueService.js - Low level application functionality regarding issuses.
```


Layouts:

```
projects.eta - A layout for viewing, adding, and removing projects.
```


```
issues.eta - A layout for viewing, adding, and removing the
```


## Function Overview

database.js

* executeQuery - Connects to the database server and runs a SQL command. Returns any output as an array of JS Objects.

requestUtils.js

* redirectTo - Routes the app to a given address.

projectController.js

* viewProjects - Requests a list of all projects from projectService.js and issue counts for each project from issueService.js. Displays projects using the projects.eta layout.
* viewProjectDetails - Requests a list of all issues for the selected project from issueService.js and displays them using the issues.eta layout.
* addProject - Passes a name to create in projectService.js.
* deleteProject - Passes an id to deleteById in projectService.js.

issueController.js

* addIssue - Passes a project_id and description to create in issueService.js.
* deleteById - Passes an issue id to deleteById in issueService.js.

projectService.js

* create - Adds a new project with a name to the database.
* deleteById - Removes a project from the database by its unique id.
* findAll - Gets a list of all projects in the database as an array of JS Objects.
* getById - Gets a specific project from the database as an array of JS Objects.

issueService.js

* create - Adds an issue with a project_id and description to the database.
* deleteById - Removes an issue from the database by its unique id.
* deleteByProject - Removes all issues associated with a given project from the database.
* findByProject - Returns a list of all issues for the selected project as an array of JS Objects.
* numberByProject - Returns an array of JS Objects each containing a project_id and the count of issues for that project.

## How To Use

You can try the app in your browser by going to [https://wsd-proj-1.herokuapp.com/projects](https://wsd-proj-1.herokuapp.com/projects). Alternatively, to run this application locally, you'll need [Deno](https://deno.land/) installed on your computer. From your command line:

```bash
# Go into the repository containing this README
$ cd proj1

# Run the app
$ deno run --allow-net --allow-read app.js
```

The app should now be running locally at [https://localhost:7777](https://localhost:7777).
