import { renderFile } from "https://deno.land/x/eta@v1.12.3/mod.ts";
import * as requestUtils from "../utils/requestUtils.js";
import * as projectService from "../services/projectService.js";
import * as issueService from "../services/issueService.js"

const viewProjects = async (request) => {
    const data = {
        projects: await projectService.findAll(),
        issuesCount: await issueService.numberByProject(),
    };

    request.respond({ body: await renderFile("projects.eta", data) });
};

const viewProjectDetails = async (request) => {
    const id = request.url.split("/")[2];
    const selectedProjects = await projectService.getById(id);
    if(selectedProjects.length != 1) {
        request.respond({ status: 303, headers: new Headers({ "Location": "/",}) });
    } else {
        const data = {
            project: selectedProjects[0],
            issues: await issueService.findByProject(id),
        };
    
        request.respond({ body: await renderFile("issues.eta", data) });
    }
};
  
const addProject = async (request) => {
    const body = new TextDecoder().decode(await Deno.readAll(request.body));
    const params = new URLSearchParams(body);

    const name = params.get("name");

    await projectService.create(name);

    await requestUtils.redirectTo(request,"/projects");
};

const deleteProject = async (request) => {
    const id = request.url.split("/")[2];
    await issueService.deleteByProject(id);
    await projectService.deleteById(id);

    await requestUtils.redirectTo(request,"/projects");
};

export { viewProjects, viewProjectDetails, addProject, deleteProject };