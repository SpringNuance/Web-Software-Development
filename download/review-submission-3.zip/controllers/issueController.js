import * as requestUtils from "../utils/requestUtils.js";
import * as issueService from "../services/issueService.js"

const addIssue = async (request) => {
    const project_id = request.url.split("/")[2];
    const body = new TextDecoder().decode(await Deno.readAll(request.body));
    const params = new URLSearchParams(body);

    const description = params.get("description");

    await issueService.create(project_id,description);

    await requestUtils.redirectTo(request,"/projects/"+project_id+"/issues");
};

const deleteById = async (request) => {
    const split_request = request.url.split("/")
    const project_id = split_request[2];
    const id = split_request[4];
    await issueService.deleteById(id);

    await requestUtils.redirectTo(request,"/projects/"+project_id+"/issues");
}

export { addIssue, deleteById };