import { executeQuery } from "../database/database.js";

// Adds a project to the database with the given name
const addProject = async(name) => {
    await executeQuery("INSERT INTO projects (name) VALUES ($1);",
    name
    );
};

const viewProjects = async() => {
    let result = await executeQuery("SELECT * FROM projects;");
    return result.rows;
};
// Finds a specific project from the database, that matches with the given project id
const findProject = async(project_id) => {
    let result = await executeQuery("SELECT * FROM projects WHERE id = $1;",
    project_id
    );
    if (result.rows && result.rows.length > 0) {
      return result.rows[0];
    };
    return false;
};
// Deletes a project from the database that matches with the given project id
const deleteProject = async(project_id) => {
    await executeQuery("DELETE FROM projects WHERE id = $1;",
    project_id
    );
};

export {addProject,viewProjects,deleteProject,findProject};