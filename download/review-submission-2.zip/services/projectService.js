import { executeQuery } from "../database/database.js";

// Adds an issue to the database when given a project id and description
const addIssue = async(project_id,description) =>{
    await executeQuery("INSERT INTO project_issues (project_id, description) VALUES ($1, $2);",
    project_id,
    description,
    );
};
// Finds issues from the database that correspond to the given project id
const findIssues = async(project_id)=>{
    let result = await executeQuery("SELECT * FROM project_issues WHERE project_id = $1;",
    project_id,
    );
    return result.rows;
};
// Solves and deletes project's issue based on the given issue id
const solveIssue = async(issue_id) =>{
    await executeQuery("DELETE FROM project_issues WHERE id = $1;",
    issue_id
    );
};
// Solves and deletes project's every issue based on the given project id
const solveAllIssue = async(project_id) =>{
    await executeQuery("DELETE FROM project_issues WHERE project_id=$1",
    project_id
    );
};

export {addIssue,findIssues,solveIssue,solveAllIssue};