PROJECTS

Projects app is a web application that is used for reporting and resolving project-specific issues. The application must use a three-tier architecture (client, server, database) and a layered architecture with four layers (views, controllers, services, database).

Features

Add/view/remove

User's of the web app on the "projects page" can add their projects to the web app by submitting the project names to the given form. The projects page now shows a list projects with their name that have been submitted. Once projects have been created users have chance to either go to a project specific page or to remove the some previously submitted projects.

In order to access a specific project's page, users need to click on the chosen project's name. Once directed to the project specific page users have a chance to add/report issues of the project to the project page. Submittion of a issue works simply by giving the description of the issue to the form submitting it. Again likewise in the projects page and it's list of projects, the issues of a certain project are shown simmilarly in a list manner and can be removed/resolved. Resolving a issue works by just clicking the resolve button next to the chosen issue.

Lastly the removal of a project. User can remove their submitted project from the projects interface. This will also remove existing issues of the project in case they have not been yet solved.

Launch

The web app can be tried and tested on https://wsd-project-123321.herokuapp.com/. The web app can also be lauched locally given that the user creates the required database(ElephantSQL) and changes the database configuration in the database/database.js pool (hostname, database, user, password, port).

Tools for running locallly:

CREATE TABLE projects (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL
);

CREATE TABLE project_issues (
  id SERIAL PRIMARY KEY,
  project_id INTEGER REFERENCES projects(id),
  description TEXT NOT NULL
);

deno run --allow-net --allow-read --unstable app.js

