import { renderFile } from "https://deno.land/x/eta@v1.12.3/mod.ts";
import * as projectsService from "../services/projectsService.js";
import * as projectService from "../services/projectService.js";
import * as requestUtils from "../utils/requestUtils.js";

//Adds a project to to the list
const addProject = async(request) => {
    const body = new TextDecoder().decode(await Deno.readAll(request.body));
    const params = new URLSearchParams(body);
    const name = params.get("name");

    await projectsService.addProject(name);
    await requestUtils.redirectTo(request,"/projects");
};
// Shows the existing list of projects
const viewProjects = async(request) => {
    const data = {
      projects: await projectsService.viewProjects(),
    };
  
    request.respond({ body: await renderFile("projects.eta", data) });
};
// Shows a project and it's issues
const viewProject = async(request) => {
    const urlParts = request.url.split("/");
    const data = {
      project: await projectsService.findProject(urlParts[2]),
      currentIssues: await projectService.findIssues(urlParts[2]),
    };
    request.respond({ body: await renderFile("project.eta", data) });
};
// Deletes a project and it's existing issues
const deleteProject = async(request) => {
  const id = request.url.split("/")[2];
  
  await projectService.solveAllIssue(id);

  await projectsService.deleteProject(id);
  await requestUtils.redirectTo(request,"/projects");
};

export{addProject,viewProjects,deleteProject,viewProject};