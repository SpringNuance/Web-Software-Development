import * as projectService from "../services/projectService.js";
import * as requestUtils from "../utils/requestUtils.js";

// Adds a issue to the project
const addIssue = async(request) => {
    const body = new TextDecoder().decode(await Deno.readAll(request.body));
    const params = new URLSearchParams(body);
    const description = params.get("description");
    const urlParts = request.url.split("/");

    await projectService.addIssue(urlParts[2],description);

    await requestUtils.redirectTo(request,`/projects/${urlParts[2]}`);
};
// Solves an issue from the project
const solveIssue = async(request) => {
    const urlParts = request.url.split("/");

    await projectService.solveIssue(urlParts[4]);
    await requestUtils.redirectTo(request,`/projects/${urlParts[2]}`);
};

export {addIssue,solveIssue};
