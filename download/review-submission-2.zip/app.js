import { serve } from "https://deno.land/std@0.100.0/http/server.ts";
import { configure } from "https://deno.land/x/eta@v1.12.3/mod.ts";
import * as projectsController from "./controllers/projectsController.js";
import * as projectController from "./controllers/projectController.js";
import * as requestUtils from "./utils/requestUtils.js";

configure({
    views: `${Deno.cwd()}/views/`,
});

let port = 7777;
const server = serve({ port: port });

for await (const request of server) {
    if (request.method === "GET" && request.url === "/") {
        await requestUtils.redirectTo(request,"/projects");
    } else if (request.method === "GET" && request.url === "/projects") {
        await projectsController.viewProjects(request);
    } else if (request.method === "POST" && request.url === "/projects") {
        await projectsController.addProject(request);
    } else if (request.method === "GET" && request.url.match("/projects/[0-9]+")) {
        await projectsController.viewProject(request);
    } else if (request.method === "POST" && request.url.match("/projects/[0-9]+/issues/[0-9]+")) {
        await projectController.solveIssue(request);
    } else if (request.method === "POST" && request.url.match("/projects/[0-9]+/issues")) {
        await projectController.addIssue(request);
    } else if (request.method === "POST" && request.url.match("/projects/[0-9]+")) {
        await projectsController.deleteProject(request);
    } else {
        request.respond({ status: 404 });
    }
}