import { Application, HttpServerStd } from "https://deno.land/x/oak@v7.7.0/mod.ts";
import { router } from "./routes/routes.js";
import { errorMiddleware } from "./middlewares/errorMiddleware.js";
import renderMiddleware from "./middlewares/renderMiddleware.js";
import { superoak } from "https://deno.land/x/superoak@4.3.0/mod.ts";

const app = new Application({
  serverConstructor: HttpServerStd,
});

app.use(errorMiddleware);
app.use(renderMiddleware);

Deno.test("Test 5 api", async () => {
  const testClient = await superoak(app);
  await testClient.get("/api/hello")
  .assertEquals({ message: helloService.getHello()}, helloApi.getHello);
});


Deno.test("Test 6 api", async () => {
  const testClient = await superoak(app);
  await testClient.post("/api/hello")
  .send({ message: "Hello world!" })
  .expect(200)
  .expect({ message: "Hello world!" })
});

app.use(router.routes());

export { app };

// if you wish to run the application, uncomment the following line
// for local testing -- remember to comment it when returning the app
// for testing
// app.listen({ port: 7777 });
