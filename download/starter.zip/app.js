import { Application, HttpServerStd, Router } from "https://deno.land/x/oak@v7.7.0/mod.ts";
import { OakSession } from "https://deno.land/x/sessions@v1.5.4/mod.ts";
import renderMiddleware from "./middlewares/renderMiddleware.js";

const app = new Application({
  serverConstructor: HttpServerStd,
});

new OakSession(app);
app.use(renderMiddleware);

const router = new Router();

const data = {
  items: [],
};

const listItems = ({ render }) => {
  render("index.eta", data);
};

const addItem = async ({ request, response }) => {
  const body = request.body();
  const params = await body.value;
  data.items.push(params.get("item"));
  response.redirect("/");
};

router.get("/", listItems);
router.post("/", addItem);

app.use(router.routes());

if (!Deno.env.get("TEST_ENVIRONMENT")) {
  app.listen({ port: 7777 });
}

export default app;
